const socket = io('http://localhost:3000')

function appendMessage() {

}

