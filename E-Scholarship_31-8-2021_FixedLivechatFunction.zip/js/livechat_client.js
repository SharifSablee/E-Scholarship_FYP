// This will work as the client of the livechat.
// Student and Institution will be able to use this.
const socket = io('http://localhost:3000');
const messageContainer = document.getElementById('message-container');
const messageForm = document.getElementById('send-container');
const messageInput = document.getElementById('message-input');
document.getElementById('livechat-btn').addEventListener('click', function() {
    const name = prompt('What is your name?');
    // alert(temp);
    appendMessage('Welcome to the livechat')
    socket.emit('new-user', name);

    socket.on('user-connected', name => {
        console.log(name);
        appendMessage(name+' connected');
    });
});

// const name = prompt('What is your name?');
socket.emit('new-user', name);

socket.on('chat-message', data => {
    appendMessage(data.name+': '+data.message);
});

socket.on('user-disconnected', name => {
    appendMessage(name+' disconnected');
});

messageForm.addEventListener('submit', e => {
    e.preventDefault();
    const message = messageInput.value;
    appendMessage('You: '+message);
    socket.emit('send-chat-message', message);
    messageInput.value = '';
});

function appendMessage(message) {
    const messageElement = document.createElement('div');
    messageElement.innerText = message;
    messageContainer.append(messageElement);
};